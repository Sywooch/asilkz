-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `iv_article`;
CREATE TABLE `iv_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Заголовок',
  `description` mediumtext NOT NULL COMMENT 'Содержание',
  `type` tinyint(4) NOT NULL COMMENT 'Тип',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT '0' COMMENT 'Видимость',
  `dateCreate` date NOT NULL COMMENT 'Дата и время',
  PRIMARY KEY (`id`),
  KEY `ixType` (`type`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_article` (`id`, `title`, `description`, `type`, `alias`, `visible`, `dateCreate`) VALUES
(1,	'Первая статья',	'Смятые в складки осадочные породы в высокогорном плато заставляют предположить, что вулканическое стекло определяет пролювий. Хребет, а также комплексы фораминифер, известные из валунных суглинков роговской серии, длительно разогревает топаз, включая и гряды Чернова, Чернышева и др. Ледниковое озеро сменяет гипергенный минерал.\r\n\r\nЛоже составляет лимнический бентос. Складчатость и надвигание свидетельствуют о том, что магматическая дифференциация полого высвобождает каркасный мергель. К сожалению, различия в силе тяжести, обусловленные изменениями плотности в мантии, цвет относительно слабо слагает разлом. Руководящее ископаемое, но если принять для простоты некоторые докущения, повсеместно сменяет триас.',	1,	'pervaya-statya',	1,	'2015-07-21'),
(2,	'Первая новость',	'Первая новость содержание',	1,	'pervaya-novost',	1,	'2015-07-21'),
(3,	'STBAR Каждый четверг',	'',	3,	'stbar-kazhdiy-chetverg',	1,	'2015-08-06'),
(4,	'Тестовая статья',	'Служба Яндекс.Рефераты предназначена для студентов и школьников, дизайнеров и журналистов, создателей научных заявок и отчетов — для всех, кто относится к тексту, как к количеству знаков.\r\n\r\nНажав на кнопку «Написать реферат», вы лично создаете уникальный текст, причем именно от вашего нажатия на кнопку зависит, какой именно текст получится — таким образом, авторские права на реферат принадлежат только вам.\r\n\r\nТеперь никто не сможет обвинить вас в плагиате, ибо каждый текст Яндекс.Рефератов неповторим.\r\n\r\nТекстами рефератов можно пользоваться совершенно бесплатно, однако при транслировании и предоставлении текстов в массовое пользование ссылка на Яндекс.Рефераты обязательна.',	1,	'testovaya-statya',	1,	'2015-08-06'),
(5,	'Чья-то Киска В зоне Риска',	'Чья-то Киска В зоне Риска теперь трек есть на TOPMUSIC.UZ \r\nСкачивай трек вот тут \r\nhttp://topmusic.uz/media/rap/lex_kingsize/',	2,	'chya-to-kiska-v-zone-riska',	1,	'2015-08-06');

DROP TABLE IF EXISTS `iv_auth_assignment`;
CREATE TABLE `iv_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `iv_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('admin',	'1',	1435050242),
('client',	'19',	1435050320),
('client',	'20',	1435560650),
('client',	'21',	1435560693),
('client',	'22',	1435561220),
('client',	'23',	1435561340),
('client',	'24',	1435561743),
('client',	'25',	1435571840),
('client',	'26',	1435574397),
('client',	'33',	1435645190),
('client',	'34',	1435645299),
('client',	'35',	1435645367),
('client',	'36',	1435901979),
('client',	'37',	1435902055),
('client',	'38',	1435902118),
('client',	'39',	1435902206),
('client',	'40',	1435902353),
('client',	'41',	1435902392),
('manager',	'2',	1435050242);

DROP TABLE IF EXISTS `iv_auth_item`;
CREATE TABLE `iv_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `iv_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `iv_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('admin',	1,	'Администраторы - пользователи со всеми привелегиями',	NULL,	NULL,	1435050242,	1435050242),
('admin.nav',	2,	'Доступ к навигации в админке',	NULL,	NULL,	1435050242,	1435050242),
('client',	1,	'Клиенты: Пользователи с возможностями: \"просмотр профиля\", \"привязка карты\", \"редактирование своего профиля\"',	NULL,	NULL,	1435050242,	1435050242),
('manager',	1,	'Менеджеры: Пользователи с возможностями: \"активация партнера\", \"админка\"',	NULL,	NULL,	1435050242,	1435050242),
('partner',	1,	'Партнеры - пользователи с возможностями: \"регистрация\", \"редактирование профиля\"',	NULL,	NULL,	1435050242,	1435050242),
('setRole',	2,	'Проставление роли',	NULL,	NULL,	1435050242,	1435050242);

DROP TABLE IF EXISTS `iv_auth_item_child`;
CREATE TABLE `iv_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `iv_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `iv_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_item_child` (`parent`, `child`) VALUES
('manager',	'admin.nav'),
('admin',	'manager'),
('manager',	'partner'),
('admin',	'setRole');

DROP TABLE IF EXISTS `iv_auth_rule`;
CREATE TABLE `iv_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `iv_image`;
CREATE TABLE `iv_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) NOT NULL COMMENT 'Изображение',
  `model` varchar(255) NOT NULL COMMENT 'Модель',
  `primaryKey` int(11) unsigned NOT NULL COMMENT 'Ключ',
  PRIMARY KEY (`id`),
  KEY `ixPrimaryKey` (`primaryKey`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_image` (`id`, `src`, `model`, `primaryKey`) VALUES
(46,	'4cf7587fdd88132ce8b3095bab3fa872.jpg',	'app\\modules\\discount\\models\\Service',	1),
(48,	'e50d66f4c8816ad2eaae386c00ff50f7.jpg',	'app\\modules\\discount\\models\\Service',	1),
(50,	'0bd6e32d92ebe86863112f8a67739e30.jpg',	'app\\modules\\discount\\models\\Service',	1),
(52,	'c0e47d705b98eef5d69a5b1a2d3452da.jpg',	'app\\modules\\discount\\models\\Service',	2),
(53,	'3d7cb7bada2ec4682d3a297e98a76d73.jpg',	'app\\modules\\discount\\models\\Service',	2),
(54,	'18e9a42947affc714af30f8acdc7fba5.jpg',	'app\\modules\\discount\\models\\Service',	2),
(55,	'647c44a0f151afd64f0032ff32b5c752.jpg',	'app\\modules\\discount\\models\\Service',	4),
(56,	'5c1075179c5ce90005ecc64197f2adea.jpg',	'app\\modules\\discount\\models\\Service',	4),
(57,	'4cf9f79fcc8d3b55cec9a7df086faa04.jpg',	'app\\modules\\discount\\models\\Service',	4),
(60,	'17809fc86930118a5a131a1664069a4b.jpg',	'app\\modules\\discount\\models\\Service',	5),
(61,	'a859c70d356748ec9421d780af1da477.jpg',	'app\\modules\\discount\\models\\Service',	5),
(62,	'a1ddd67670a7a78c1c824c66e29d40a9.jpg',	'app\\modules\\discount\\models\\Service',	5),
(63,	'25726a58310c4c13b71cf7553b55f4ed.jpg',	'app\\modules\\discount\\models\\Service',	6),
(64,	'de7e269b19b4e8e2edca9912acebd10b.jpg',	'app\\modules\\discount\\models\\Service',	1),
(65,	'41bb6810fd41d7d4a2ae53eafcf1b55d.jpg',	'app\\modules\\discount\\models\\Service',	1),
(66,	'3dddaf83cc238876bbf16dd53b10421e.jpg',	'app\\modules\\discount\\models\\Service',	1),
(67,	'fd243f78e65043f599f27d579e2c5225.jpg',	'app\\modules\\discount\\models\\Service',	7),
(68,	'70bb456d5b707fcbb8a608a3f5425056.jpg',	'app\\modules\\discount\\models\\Service',	7),
(69,	'dbfef95d28733c83de0f0cf620f26f5e.jpg',	'app\\modules\\discount\\models\\Service',	7),
(72,	'9b747a412fe82f0ee4ec963ef04bad8c.jpg',	'app\\modules\\cms\\models\\Article',	1),
(73,	'35d87d9a12eb719206f37094b3c8b426.jpg',	'app\\modules\\cms\\models\\Article',	2),
(74,	'44640438c3bc54c6fa6b04d5ec94f5f7.jpg',	'app\\modules\\cms\\models\\Reviews',	1),
(75,	'0d063fd2a9f6060fbbd46f292b42e73f.jpg',	'app\\modules\\cms\\models\\Reviews',	2),
(76,	'e807aca866ca0c643a3fcc57e0237247.jpg',	'app\\modules\\store\\models\\Category',	1),
(77,	'a6e24447b3ba8b6fe830efc725f11009.jpg',	'app\\modules\\store\\models\\Category',	2),
(78,	'14952ffd36cdb6cab23ff922a30d8fa9.jpg',	'app\\modules\\store\\models\\Category',	3),
(79,	'eb79a2a4bfa2144a46ff25efe532a951.jpg',	'app\\modules\\store\\models\\Manufacturer',	1),
(80,	'40fc3b87f924b17c0aeaba8d8dbfce0c.jpeg',	'app\\modules\\store\\models\\Product',	1),
(81,	'917c386a864008171d127c7011c644b0.jpg',	'app\\modules\\store\\models\\Product',	2),
(82,	'70244f66f7f28c436c7e74974ce52600.png',	'app\\modules\\store\\models\\Product',	3),
(83,	'ff5049facf20643f840a7d506cb76786.jpg',	'app\\modules\\cms\\models\\Article',	3),
(84,	'e957acf3970d2d6e633d16ab54e12115.jpg',	'app\\modules\\cms\\models\\Article',	4),
(86,	'f8816a8abc6c3093e47ebbf639b1343b.jpg',	'app\\modules\\cms\\models\\Article',	5);

DROP TABLE IF EXISTS `iv_migration`;
CREATE TABLE `iv_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_migration` (`version`, `apply_time`) VALUES
('m140506_102106_rbac_init',	1431932009),
('m150515_120931_category_create',	1431691987),
('m150515_125008_page_create',	1431694293),
('m150518_064104_user_create',	1431931462),
('m150518_122627_city_create',	1431952171),
('m150519_065503_discount_category',	1432018597),
('m150519_074745_discount_partner',	1432021842),
('m150519_103355_discount_service_create',	1432035168),
('m150519_125442_image_create',	1432040901),
('m150521_075614_service_drop_field_image',	1432195091),
('m150521_100916_discount_service_addField_alias',	1432203026),
('m150522_114055_discount_request',	1432636877),
('m150525_130756_discount_card',	1432636877),
('m150526_141201_userProfile_create',	1432649792),
('m150527_131458_user_profile_add_photo',	1432732639),
('m150528_080148_partner_fieldAdd_userId',	1432800178),
('m150528_083508_discount_history_create',	1432802518),
('m150528_130124_discount_request_addField_type',	1432818156),
('m150529_070307_discount_partner_addField_cords',	1432883088),
('m150603_103510_pyramid_create',	1433331955),
('m150604_052012_card_addField_type',	1433395332),
('m150604_062018_user_pyramid',	1433398992),
('m150616_103055_card_addfield_number',	1434450737),
('m150629_052329_partner',	1435557479),
('m150629_095021_user_addfield_dateCreate',	1435645058),
('m150629_110745_user_balance',	1435645058);

DROP TABLE IF EXISTS `iv_page`;
CREATE TABLE `iv_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `description` text,
  `metaKeywords` varchar(255) DEFAULT NULL,
  `metaDescription` varchar(255) DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visible` smallint(6) DEFAULT NULL,
  `parentId` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixParent` (`parentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_page` (`id`, `title`, `alias`, `description`, `metaKeywords`, `metaDescription`, `dateCreate`, `visible`, `parentId`) VALUES
(1,	'О компании',	'o-kompanii',	'<div class=\"title rel\">\r\n	<h2>О компании</h2>\r\n</div>\r\n<div class=\"text\">\r\n	<img src=\"img/opt.jpg\"/>\r\n	<p>\r\n		Компания «ВЕТМАРКЕТ» была основана в 1996 году как профессиональная ветеринарная компания, специализирующаяся на продвижении и продажах ветеринарных препаратов, средств гигиены и оборудования, инструментов и приборов для ветеринарии мелких домашних животных.  ООО «ВЕТМАРКЕТ» входит в Группу Компаний «ВИК», которая на ветеринарном рынке уже 25 лет.\r\n					ООО «ВЕТМАРКЕТ» является официальным дистрибьютором Zoetis, MSD Animal Health, GIGI, Хелвет, Астрафарм и др., а также активно занимается продвижением собственной продукции «ВИК - здоровье животных» для домашних питомцев по программе «Подари другу здоровье»  торговой марки «Доктор ВИК», в которую входят препараты для лечения заболеваний опорно-двигательного аппарата животных, противовоспалительные и противопаразитарные средства, препарат для анестезии и эвтаназии животных, профессиональная серия шампуней, бальзамов и кондиционеров - Doctor VIC Professional, наполнители и различные расходные материалы. \r\n					Вся продукция «ВИК - здоровье животных» выпускается на заводах в г. Витебск (РБ) и в г. Белгород (РФ), которые имеют аттестацию производства по европейским стандартам качества GMP. Главный девиз компании - «Европейское качество по Российским ценам».\r\n	</p>\r\n\r\n</div>\r\n<div class=\"title rel\">\r\n	<h2>Вакансии</h2>\r\n</div>\r\n<div class=\"text\">\r\n	<p>\r\n		Вся продукция «ВИК - здоровье животных» выпускается на заводах в г. Витебск (РБ) и в г. Белгород (РФ), которые имеют аттестацию производства по европейским стандартам качества GMP. Главный девиз компании - «Европейское качество по Российским ценам».\r\n	</p>\r\n</div>\r\n<div class=\"title rel\">\r\n	<h2>Консультанты</h2>\r\n</div>\r\n<div class=\"text\">\r\n	<ul class=\"vrach consult\">\r\n		<li>\r\n			<div class=\"vrach_dannie \">\r\n				<img src=\"img/krug.jpg\">\r\n				<span> <b>Имя Фамилия</b>\r\n				</br>\r\n				+7 (777) 77-77-77\r\n			</span>\r\n		</div>\r\n	</li>\r\n	<li>\r\n		<div class=\"vrach_dannie\">\r\n			<img src=\"img/krug.jpg\">\r\n			<span> <b>Имя Фамилия</b>\r\n			</br>\r\n			+7 (777) 77-77-77\r\n		</span>\r\n	</div>\r\n</li>\r\n<li>\r\n	<div class=\"vrach_dannie\">\r\n		<img src=\"img/krug.jpg\">\r\n		<span>\r\n			<b>Имя Фамилия</b>\r\n		</br>\r\n		+7 (777) 77-77-77\r\n	</span>\r\n</div>\r\n</li>\r\n</ul>\r\n</div>',	'',	'',	'2015-08-04 06:39:52',	1,	0),
(2,	'Оптовым клиентам',	'optovim-klientam',	'<div class=\"title rel\">\r\n	<h2>Оптовым клиентам</h2>\r\n</div>\r\n<div class=\"text\">\r\n	<img src=\"img/opt.jpg\"/>\r\n	<p>\r\n		Компания «ВЕТМАРКЕТ» была основана в 1996 году как профессиональная ветеринарная компания, специализирующаяся на продвижении и продажах ветеринарных препаратов, средств гигиены и оборудования, инструментов и приборов для ветеринарии мелких домашних животных.  ООО «ВЕТМАРКЕТ» входит в Группу Компаний «ВИК», которая на ветеринарном рынке уже 25 лет.\r\n					ООО «ВЕТМАРКЕТ» является официальным дистрибьютором Zoetis, MSD Animal Health, GIGI, Хелвет, Астрафарм и др., а также активно занимается продвижением собственной продукции «ВИК - здоровье животных» для домашних питомцев по программе «Подари другу здоровье»  торговой марки «Доктор ВИК», в которую входят препараты для лечения заболеваний опорно-двигательного аппарата животных, противовоспалительные и противопаразитарные средства, препарат для анестезии и эвтаназии животных, профессиональная серия шампуней, бальзамов и кондиционеров - Doctor VIC Professional, наполнители и различные расходные материалы. \r\n					Вся продукция «ВИК - здоровье животных» выпускается на заводах в г. Витебск (РБ) и в г. Белгород (РФ), которые имеют аттестацию производства по европейским стандартам качества GMP. Главный девиз компании - «Европейское качество по Российским ценам».\r\n	</p>\r\n</div>\r\n<div class=\"title rel\">\r\n	<h2>Ветеренарные врачи</h2>\r\n</div>\r\n<div class=\"text\">\r\n	<ul class=\"vrach\">\r\n		<li>\r\n			<div class=\"vrach_dannie\">\r\n				<img src=\"img/krug.jpg\">\r\n				<span> <b>Имя Фамилия</b>\r\n				</br>\r\n				+7 (777) 77-77-77\r\n			</span>\r\n		</div>\r\n	</li>\r\n	<li>\r\n		<div class=\"vrach_dannie\">\r\n			<img src=\"img/krug.jpg\">\r\n			<span> <b>Имя Фамилия</b>\r\n			</br>\r\n			+7 (777) 77-77-77\r\n		</span>\r\n	</div>\r\n</li>\r\n</ul>\r\n</div>',	'',	'',	'2015-08-04 06:45:18',	1,	0),
(3,	'Оплата и доставка',	'oplata-i-dostavka',	'<div class=\"title rel\">\r\n	<h2>Оплата и доставка</h2>\r\n</div>\r\n<div class=\"text\">\r\n	<img src=\"img/opt.jpg\"/>\r\n	<p>\r\n		Компания «ВЕТМАРКЕТ» была основана в 1996 году как профессиональная ветеринарная компания, специализирующаяся на продвижении и продажах ветеринарных препаратов, средств гигиены и оборудования, инструментов и приборов для ветеринарии мелких домашних животных.  ООО «ВЕТМАРКЕТ» входит в Группу Компаний «ВИК», которая на ветеринарном рынке уже 25 лет.\r\n					ООО «ВЕТМАРКЕТ» является официальным дистрибьютором Zoetis, MSD Animal Health, GIGI, Хелвет, Астрафарм и др., а также активно занимается продвижением собственной продукции «ВИК - здоровье животных» для домашних питомцев по программе «Подари другу здоровье»  торговой марки «Доктор ВИК», в которую входят препараты для лечения заболеваний опорно-двигательного аппарата животных, противовоспалительные и противопаразитарные средства, препарат для анестезии и эвтаназии животных, профессиональная серия шампуней, бальзамов и кондиционеров - Doctor VIC Professional, наполнители и различные расходные материалы. \r\n					Вся продукция «ВИК - здоровье животных» выпускается на заводах в г. Витебск (РБ) и в г. Белгород (РФ), которые имеют аттестацию производства по европейским стандартам качества GMP. Главный девиз компании - «Европейское качество по Российским ценам».\r\n	</p>\r\n	<ul  class=\"oplata\">\r\n		<li>\r\n			<span>Заказчик:</span>\r\n			ТОО “Асыл Кокше Зооветснаб”\r\n		</li>\r\n		<li>\r\n			<span>ИИН/БИН:</span>\r\n			111240012799\r\n		</li>\r\n		<li>\r\n			<span>Директор:</span>\r\n			Тосмурзина Б.Ш.\r\n		</li>\r\n	</ul>\r\n</div>',	'',	'',	'2015-08-04 06:49:13',	1,	0),
(4,	'Контакты',	'kontakti',	'<div class=\"title rel\">\r\n	<h2>Контакты</h2>\r\n</div>\r\n<div class=\"text\">\r\n\r\n	<ul  class=\"oplata cont\">\r\n		<li>\r\n			<span>Адрес:</span>\r\n			020000, Р.К. Акмолинская область, г. Кокшетау, ул. Ш. Уалиханова, 52.\r\n		</li>\r\n		<li>\r\n			<span>Тел:</span>\r\n			+7 716 278-17-67\r\n		</li>\r\n		<li>\r\n			<span>Сотовый:</span>\r\n			+7 707 707-00-77\r\n		</li>\r\n		<li>\r\n			<span>E-mail:</span>\r\n			mail@mail.ru\r\n		</li>\r\n	</ul>\r\n	<div class=\"map\">\r\n		<script type=\"text/javascript\" charset=\"utf-8\" src=\"https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=F7RXAtg54SA9ax--SWYp5RiPDzDIGjaP&width=100%&height=260\"></script>\r\n	</div>\r\n</div>',	'',	'',	'2015-08-04 07:01:28',	1,	0);

DROP TABLE IF EXISTS `iv_reviews`;
CREATE TABLE `iv_reviews` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL COMMENT 'Имя',
  `age` int(11) DEFAULT NULL COMMENT 'Возраст',
  `company` varchar(128) DEFAULT NULL COMMENT 'Компания',
  `content` varchar(300) DEFAULT NULL COMMENT 'Отзыв',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  PRIMARY KEY (`id`),
  KEY `ixVisible` (`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_reviews` (`id`, `name`, `age`, `company`, `content`, `visible`) VALUES
(1,	'Иван',	27,	'Astana Creative',	'Молодцы ребята могёте!',	1),
(2,	'Готя Романовский',	25,	'ST Bar',	'Обратился в эту команду и меня поняли с первого слова. Буду еще к вам обращаться, так держать.',	1);

DROP TABLE IF EXISTS `iv_store_basket`;
CREATE TABLE `iv_store_basket` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `productId` int(11) unsigned DEFAULT NULL COMMENT 'Товар',
  `quantity` int(11) unsigned DEFAULT NULL COMMENT 'Кол-во',
  `dataCreate` datetime DEFAULT NULL COMMENT 'Дата и время добавления',
  `sessionId` varchar(64) DEFAULT NULL COMMENT 'Айди корзины',
  `type` tinyint(4) DEFAULT NULL COMMENT 'Тип (Корзина, заказ)',
  `position` int(11) DEFAULT NULL COMMENT 'Позиция в корзине',
  PRIMARY KEY (`id`),
  KEY `ixProductId` (`productId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_category`;
CREATE TABLE `iv_store_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  `position` int(11) DEFAULT NULL COMMENT 'Позивия',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixPosition` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_category` (`id`, `title`, `alias`, `visible`, `position`) VALUES
(1,	'Антибиотики',	'antibiotiki',	1,	1),
(2,	'Вакцини и сыворотки',	'vakcini-i-sivorotki',	1,	2),
(3,	'Витамины и менералы',	'vitamini-i-menerali',	1,	3);

DROP TABLE IF EXISTS `iv_store_manufacturer`;
CREATE TABLE `iv_store_manufacturer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  `position` int(11) DEFAULT NULL COMMENT 'Позиция',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixPosition` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_manufacturer` (`id`, `title`, `alias`, `visible`, `position`) VALUES
(1,	'Хелвет',	'helvet',	1,	1);

DROP TABLE IF EXISTS `iv_store_order`;
CREATE TABLE `iv_store_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fio` varchar(128) DEFAULT NULL COMMENT 'ФИО',
  `phone` varchar(23) DEFAULT NULL COMMENT 'Телефон',
  `email` varchar(64) DEFAULT NULL COMMENT 'Email',
  `dateCreate` datetime DEFAULT NULL COMMENT 'Дата и время',
  `statusId` tinyint(4) DEFAULT NULL COMMENT 'Статус',
  `secretKey` varchar(32) DEFAULT NULL COMMENT 'Доступ',
  PRIMARY KEY (`id`),
  KEY `ixStatusId` (`statusId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_order` (`id`, `fio`, `phone`, `email`, `dateCreate`, `statusId`, `secretKey`) VALUES
(1,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	NULL,	NULL,	NULL),
(2,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	NULL,	NULL,	NULL),
(3,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	NULL,	NULL,	NULL),
(4,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	'2015-08-06 11:27:53',	1,	'331f6cfdd75515099e86c38a0b04188c'),
(5,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	'2015-08-06 11:28:36',	1,	'47c58e19476ae4e815767080386a1ce7'),
(6,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	'2015-08-06 11:29:22',	1,	'f46e523c279781766fbaeaaa63271cb6'),
(7,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	'2015-08-06 11:30:16',	1,	'e3658c45803b7b762627e35507970b59'),
(8,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	'2015-08-06 11:32:35',	1,	'5e26f13eadd3439de9891630116dda13'),
(9,	'Иван',	'+9999е43549',	'vodyanov.ivan@yandex.ru',	'2015-08-06 11:34:54',	1,	'114350df14a6973d172df3cb1a730151'),
(10,	'Тест Тестов',	'87024111111',	'orb.effect@mail.ru',	'2015-08-06 12:08:03',	1,	'e6065b3951d8757bd9c6e7496ebd88f8'),
(11,	'Test Testov',	'87024111111',	'orb.effect@mail.ru',	'2015-08-06 12:09:51',	3,	'e5c03306a45f11db626e29d2787ea06b');

DROP TABLE IF EXISTS `iv_store_order_item`;
CREATE TABLE `iv_store_order_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `orderId` int(11) unsigned DEFAULT NULL COMMENT 'Заказ',
  `productId` int(11) unsigned DEFAULT NULL COMMENT 'Товар',
  `quantity` int(11) DEFAULT NULL COMMENT 'Кол-во',
  PRIMARY KEY (`id`),
  KEY `ixProductId` (`productId`),
  KEY `ixOrderId` (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_order_item` (`id`, `orderId`, `productId`, `quantity`) VALUES
(1,	4,	2,	3),
(2,	4,	3,	1),
(3,	5,	2,	3),
(4,	5,	3,	1),
(5,	6,	2,	3),
(6,	6,	3,	1),
(7,	7,	2,	3),
(8,	7,	3,	1),
(9,	8,	2,	3),
(10,	8,	3,	5),
(11,	9,	2,	8),
(12,	9,	3,	6),
(13,	10,	1,	2),
(14,	11,	2,	3),
(15,	11,	3,	2);

DROP TABLE IF EXISTS `iv_store_product`;
CREATE TABLE `iv_store_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `categoryId` int(11) unsigned NOT NULL COMMENT 'Категория',
  `manufacturerId` int(11) NOT NULL COMMENT 'Производитель',
  `content` varchar(300) DEFAULT '' COMMENT 'Описание',
  `minCount` int(10) unsigned DEFAULT '0' COMMENT 'Минимальный заказ',
  `quantity` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Кол-во на складе',
  `visible` tinyint(4) DEFAULT '0' COMMENT 'Видимость',
  PRIMARY KEY (`id`),
  KEY `ixCategoryId` (`categoryId`),
  KEY `ixManufacturerId` (`manufacturerId`),
  KEY `ixAlias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_product` (`id`, `title`, `alias`, `categoryId`, `manufacturerId`, `content`, `minCount`, `quantity`, `visible`) VALUES
(1,	'ВЕРАКОЛ, 10 мл',	'verakol-10-ml',	1,	1,	'Максимальная скорость вращения ротора тренажера Energy ball с компьютерной балансировкой гироскопа достигает 15000 оборотов в минуту. Укрепляет пальцы и кисти рук, тонизирует дельтовидные мышцы плеча, предплечья, бицепсы и трицепсы, развивает силу хвата и выносливость. Конструкция: счетчик оборотов,',	1,	114,	1),
(2,	'Кетамол, 50 мл',	'ketamol-50-ml',	2,	1,	'Перчатки обеспечивают комфорт и безопасность во время интенсивных тренировок. Предотвращают появление мозолей. Позволяют надежнее фиксировать снаряд в руках.',	3,	200,	1),
(3,	'Комплевит, 300гр',	'komplevit-300gr',	2,	1,	'Показания: Гиповитаминоз, гиперлипидемия, снижение толерантности к углеводам, атеросклероз (ранние проявления), перенесенные тяжелые заболевания, ослабленная общая сопротивляемость организма (весенне-зимний период). Противопоказания: Гиперчувствительность.',	1,	108,	1);

DROP TABLE IF EXISTS `iv_user`;
CREATE TABLE `iv_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `auth_key` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `dateCreate` datetime DEFAULT NULL COMMENT 'Дата регистрации',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user` (`id`, `username`, `password`, `auth_key`, `password_reset_token`, `dateCreate`) VALUES
(1,	'admin',	'$2y$13$ArLAzOtWEgnMbK2FEhsSa.NrcbCg9FXtaGvmAownBd4RVon5hEEOO',	'',	NULL,	NULL),
(2,	'manager',	'$2y$13$0RmhBJluvaJ5ImW6yzPQ0eGvppuQ3NzwirgjxWPNffGeKYWXOIWgW',	'\0s',	NULL,	NULL),
(33,	'vodyanov.ivan@yandex.ru',	'$2y$13$4U2Xasj0BbeF3Uu0t2nyrubmGONBluLR6TEXv2ukzCbSr31gtQ7nS',	'P',	NULL,	NULL),
(40,	'viadeveloper@gmail.com',	'$2y$13$Q5ZZ4E.9WtlK9lMlzrNpXOAtOv5JRd/9yW3VJ8k9vXJelUsfWeZ3K',	'\Z2',	NULL,	'2015-07-03 11:45:52'),
(41,	'x_vans_x@mail.ru',	'$2y$13$2TaZlTVBy6m0wTBCudFsDu8TYQEBsdbFmvmNRnmeqVzQ1To0ujXvK',	'',	NULL,	'2015-07-03 11:46:31');

DROP TABLE IF EXISTS `iv_user_balance_history`;
CREATE TABLE `iv_user_balance_history` (
  `id` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL COMMENT 'Пользователь',
  `type` smallint(6) NOT NULL COMMENT 'Тип операции',
  `sum` decimal(20,2) NOT NULL COMMENT 'Сумма',
  `date` datetime NOT NULL COMMENT 'Дата и время',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_balance_history` (`id`, `userId`, `type`, `sum`, `date`) VALUES
('b2330fc4531de135266de49078c270dd',	33,	1,	1000.00,	'2015-07-03 11:46:31'),
('c0c783b5fc0d7d808f1d14a6e9c8280d',	33,	1,	1000.00,	'2015-07-03 11:45:52'),
('d8e957bd2da1e36a73234faefd0547b3',	33,	2,	100.00,	'2015-07-03 11:51:51');

DROP TABLE IF EXISTS `iv_user_partner`;
CREATE TABLE `iv_user_partner` (
  `userId` int(11) NOT NULL COMMENT 'Пользователь',
  `partnerId` int(11) NOT NULL COMMENT 'Партнер',
  KEY `unique` (`userId`,`partnerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_partner` (`userId`, `partnerId`) VALUES
(40,	33),
(41,	33);

DROP TABLE IF EXISTS `iv_user_profile`;
CREATE TABLE `iv_user_profile` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cityId` int(11) DEFAULT NULL,
  `photo` varchar(255) NOT NULL,
  `balance` decimal(20,2) DEFAULT '0.00' COMMENT 'Баланс',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_profile` (`userId`, `phone`, `name`, `cityId`, `photo`, `balance`) VALUES
(1,	'+998909124218',	'Водянов Иван',	2,	'',	0.00),
(33,	'+998712962849',	'Водянов Иван Александрович',	3,	'',	1900.00),
(40,	'+998712962849',	'Водянов Иван Александрович',	1,	'',	0.00),
(41,	'+998909124218',	'ViaDeveloper',	3,	'',	0.00);

DROP TABLE IF EXISTS `iv_user_pyramid`;
CREATE TABLE `iv_user_pyramid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ixParentId` (`parentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2015-08-07 07:13:36
